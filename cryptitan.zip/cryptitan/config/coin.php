<?php

return [
    'testnet' => (bool) env('COIN_TESTNET', false),
    'webhook_url' => env('COIN_WEBHOOK_URL'),
];
